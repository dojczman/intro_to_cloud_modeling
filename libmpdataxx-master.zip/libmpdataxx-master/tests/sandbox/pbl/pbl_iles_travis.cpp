/** 
 * @file
 * @copyright University of Warsaw
 * @section LICENSE
 * GPLv3+ (see the COPYING file or http://www.gnu.org/licenses/)
 */

#include "pbl_test_def.hpp"

int main()
{
  test<iles_tag>("out_pbl_iles_travis", 33, 601);
}
