// unit test for the git_revision.h file
//
// author[s]: Sylwester Arabas
// licensing: GPU GPL v3
// copyright: University of Warsaw

#include <libmpdata++/git_revision.hpp>

#include <iostream>

int main() 
{
  std::cerr << LIBMPDATAXX_GIT_REVISION << std::endl;
}
