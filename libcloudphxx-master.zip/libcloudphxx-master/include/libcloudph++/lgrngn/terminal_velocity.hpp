#pragma once 

namespace libcloudphxx
{
  namespace lgrngn
  {
    namespace vt_t //separate namespace to avoid member name conflicts with kernel enumerator, TODO: in c++11 change it to an enum class
    {   
//<listing>
      enum vt_t { undefined, beard76, beard77, beard77fast, khvorostyanov_spherical, khvorostyanov_nonspherical }; 
//</listing>
    }; 
  };
};
