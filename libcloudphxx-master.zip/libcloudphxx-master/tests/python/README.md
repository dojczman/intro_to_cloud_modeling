pytest test and WRF related files are now in the cloudtest repository
