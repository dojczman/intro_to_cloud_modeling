import pytest

import sys 
sys.path.append(".")

import libcloudphxx

def test_hello():
  assert True
