//#include <libcloudph++/lgrngn/particles.hpp> // cannot include berfore "make install" :(

//using namespace libcloudphxx::lgrngn;

int main()
{
//  particles<float, cuda> p_cuda(100, 0, 0, 0);
//  particles<float, omp> p_omp(100, 0, 0, 0);
//  particles<float, cpp> p_cpp(100, 0, 0, 0);
}
